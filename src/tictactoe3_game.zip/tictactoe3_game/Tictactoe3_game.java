
package tictactoe3_game;

public class Tictactoe3_game {

    
    public static void main(String[] args) {
        
        new UserPanel();
       
    }
    
}
